﻿namespace Estates.Interfaces
{
    public interface IOffice : IBuildingEstate
    {

    }
}
